<?php
/************************************************************************/
/* Platinum Nuke Pro: Expect to be impressed                  COPYRIGHT */
/*                                                                      */
/* Copyright (c) 2004 - 2006 by http://www.techgfx.com                  */
/*     Techgfx - Graeme Allan                       (goose@techgfx.com) */
/*                                                                      */
/* Copyright (c) 2004 - 2006 by http://www.nukeplanet.com               */
/*     Loki / Teknerd - Scott Partee           (loki@nukeplanet.com)    */
/*                                                                      */
/* Copyright (c) 2007 - 2013 by http://www.platinumnukepro.com          */
/*                                                                      */
/* Refer to platinumnukepro.com for detailed information on this CMS    */
/*******************************************************************************/
/* This file is part of the PlatinumNukePro CMS - http://platinumnukepro.com   */
/*                                                                             */
/* This program is free software; you can redistribute it and/or               */
/* modify it under the terms of the GNU General Public License                 */
/* as published by the Free Software Foundation; either version 2              */
/* of the License, or any later version.                                       */
/*                                                                             */
/* This program is distributed in the hope that it will be useful,             */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of              */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               */
/* GNU General Public License for more details.                                */
/*                                                                             */
/* You should have received a copy of the GNU General Public License           */
/* along with this program; if not, write to the Free Software                 */
/* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
/*******************************************************************************/
if (stristr(htmlentities($_SERVER['PHP_SELF']), "header.php")) {
    Header("Location: index.php");
    die();
}

if (!defined('NUKE_HEADER')) {
define('NUKE_HEADER', true);
}
require_once("mainfile.php");

/******GT-NExtGEn 0.4/0.5 by Bill Murrin (Audioslaved) http://gt.audioslaved.com (c) 2004********/
/******Modified by montego from http://montegoscripts.com for TegoNuke(tm) ShortLinks********/
global $tnsl_bUseShortLinks, $tnsl_bAutoTapBlocks, $tnsl_bAutoTapLinks, $tnsl_bDebugShortLinks, $tnsl_sGTFilePath;
if (defined('TNSL_USE_SHORTLINKS')) {
  $GLOBALS['tnsl_asGTFilePath'] = tnsl_fPageTapStart();
}

##################################################
# Include some common header for HTML generation #
##################################################

//$header = 1;

function head() {
/*****************************************************/
/* Security - Sentinel v.2.5.10                START */
/*****************************************************/
    global $ab_config, $slogan, $sitename, $banners, $nukeurl, $Version_Num, $artpage, $topic, $hlpfile, $user, $hr, $theme, $cookie, $bgcolor1, $bgcolor2, $bgcolor3, $bgcolor4, $textcolor1, $textcolor2, $forumpage, $adminpage, $userpage, $pagetitle, $name, $db, $prefix;
/*****************************************************/
/* Security - Sentinel v.2.5.10                  END */
/*****************************************************/
    include_once("includes/ipban.php");
/***START*********Initialize CSS and JS arrays ********/
/************RN Compatability Layer part 1 ********/
	$headCSS = array();
	addCSSToHead(INCLUDE_PATH . 'themes/pnpro.css', 'file');
	$headJS  = array();  // added inside HEAD tags
	$bodyJS  = array(); // added at bottom of page, before </BODY>
/***END*********Initialize CSS and JS arrays ********/
/************RN Compatability Layer part 1 ********/	
    $ThemeSel = get_theme();
    include_once("themes/$ThemeSel/theme.php");
    echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n";
    echo "<html>\n";
    echo "<head>\n";
    include_once('includes/meta.php');
/***START****If Dynamic Titles are turned on, use them, otherwise, use default PHP-Nuke page titles********/
    global $useDynamicTitles;
    if (isset($useDynamicTitles) && $useDynamicTitles && file_exists(INCLUDE_PATH.'includes/dynamic_titles.php')) {
      include_once(INCLUDE_PATH.'includes/dynamic_titles.php');
  } else {
          echo '<title>'.$sitename.' '.$pagetitle.'</title>'."\n";
  }
/***END*******End of Dynamic Titles changes********/
//    include_once('includes/javascript.php');
		
    if (file_exists("themes/$ThemeSel/images/favicon.ico")) {
	echo "<link REL=\"shortcut icon\" HREF=\"themes/$ThemeSel/images/favicon.ico\" TYPE=\"image/x-icon\">\n";
    }
    if (file_exists('favicon.ico')) {
        echo '<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />'."\n";
    }
    echo '<link rel="alternate" type="application/rss+xml" title="RSS" href="backend.php" />'."\n";
    echo '<link rel="alternate" type="application/rss+xml" title="RSS" href="forumsbackend.php" />'."\n";
    echo '<link rel="StyleSheet" href="themes/'.$ThemeSel.'/style/style.css" type="text/css" />'."\n\n";

    if (file_exists('includes/custom_files/custom_head.php')) {
        include_once('includes/custom_files/custom_head.php');
    }
/***START*********Initialize CSS and JS arrays ********/
/***Support custom CSS on a per-module basis *****/
/***Module authors need to define PN_MODULE_CSS to name the external style sheet they want to load*****/
/***and we will add a link to their stylesheet file automatically.*****/
/************RN Compatability Layer part 2 ********/	
if (defined('PN_MODULE_CSS')) {
		$modCssFile = 'themes/' . $ThemeSel . '/style/' . PN_MODULE_CSS;
		if (file_exists($modCssFile)) {
			addCSSToHead($modCssFile, 'file');
		}
	}
include_once NUKE_INCLUDE_DIR . 'javascript.php';
$addons = readDIRtoArray(NUKE_INCLUDE_DIR . 'addons', '/^head\-(.+)\.php/');
	foreach ($addons as $addon) {
		include_once NUKE_INCLUDE_DIR . 'addons/'.$addon;
	}
	$addons = readDIRtoArray(NUKE_INCLUDE_DIR . 'addons', '/^body\-(.+)\.php/');
	foreach ($addons as $addon) {
		include_once NUKE_INCLUDE_DIR . 'addons/'.$addon;
	}
	if (defined('PN_MODULE_HEAD'))
	include_once NUKE_MODULES_DIR . $name . '/' . PN_MODULE_HEAD;
	writeHEAD();
/***END*********Initialize CSS and JS arrays ********/
/************RN Compatability Layer part 2 ********/	
    echo "\n\n</head>\n\n";
    if (file_exists('includes/custom_files/custom_header.php')) {
        include_once('includes/custom_files/custom_header.php');
    }
/*****************************************************/
/* Security - Sentinel v.2.5.17                 START */
/*****************************************************/
    global $ab_config;
	if ($ab_config['site_switch'] == 1 && isset($_COOKIE['admin']) && is_admin($_COOKIE['admin'])) {
		echo '<center><img src="images/nukesentinel/disabled.png" alt="' . _AB_SITEDISABLED . '" title="' . _AB_SITEDISABLED . '" border="0" /></center><br />';
	}
	if ($ab_config['disable_switch'] == 1 && isset($_COOKIE['admin']) && is_admin($_COOKIE['admin'])) {
		echo '<center><img src="images/nukesentinel/inactive.png" alt="' . _AB_NSDISABLED . '" title="' . _AB_NSDISABLED . '" border="0" /></center><br />';
    }
	if ($ab_config['test_switch'] == 1 && isset($_COOKIE['admin']) && is_admin($_COOKIE['admin'])) {
		echo '<center><img src="images/nukesentinel/testmode.png" alt="' . _AB_TESTMODE . '" title="' . _AB_TESTMODE . '" border="0" /></center><br />';
    }
/*****************************************************/
/* Security - Sentinel v.2.5.17                   END */
/*****************************************************/
/*****[BEGIN]******************************************/
/******Base:    Snavi Menu Bar            v2.5.********/
/*******************************************************/

if (defined('SNAVI_IS_ACTIVE') && file_exists('includes/snavi/snavi.php'))
{
  echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">' . "\n";
  echo '<tr><td align="center" valign="middle">' . "\n";

  include_once('includes/snavi/snavi.php');

  echo '</td></tr></table>' . "\n";
  echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">' . "\n";
  echo '<tr><td align="center" valign="top">' . "\n";
  echo '</td></tr></table>' . "\n";
}
/*****[END]********************************************
 [ Base:    Snavi Menu Bar                       v2.5.]
 ******************************************************/
    themeheader();
/*****************************************************/
/* Log In Bar - sgtmudd                        START */
/* boxover added PNP051511- DocHaVoc                 */
/*****************************************************/		
  if (is_user($user)) {
       echo "&nbsp;\n";
    }else {
       echo "<link rel=\"stylesheet\" href=\"includes/infobar/infobar.css\" type=\"text/css\" />\n";
       echo "  <table align=\"center\" class=\"infobar\" width=\"99%\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\">\n";
       echo "    <tr>\n";
       echo "      <td>\n";
       echo "        <div id=\"infobar\"><i><strong>Attention...You are not logged in...Please login or register an account</strong></i>&nbsp;<br /><a href=\"modules.php?name=Your_Account\" title=\"cssheader=[boxhdr] cssbody=[boxbdy] header=['Login or Register']body=['Click Here to log into Your Account or Register a New Account']\">&nbsp;&nbsp;<strong>Click HERE</strong>.</a></div>\n";
       echo "      </td>\n";
       echo "    </tr>\n";
       echo "  </table>\n";
       echo "<br />\n";
    }
/*****************************************************/
/* Log In Bar                                    END */
/*****************************************************/		
}

online();
head();
include_once('includes/counter.php');

/*****************************************************/
/* Addon - Center Blocks v.2.1.1               START */
/* Addon - Conditional Blocks v.1.1.1          START */
/*****************************************************/
global $home;
if(defined('HOME_FILE') || $home == 1) {
    message_box();
        include_once("includes/cblocks1.php");
    blocks('Center');
}
/*****************************************************/
/* Addon - Conditional Blocks v.1.1.1            END */
/* Addon - Center Blocks v.2.1.1                 END */
/*****************************************************/
?>
