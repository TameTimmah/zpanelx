<?php

/********************************************************/
/* NSN Groups                                           */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2005 by NukeScripts Network         */
/********************************************************/

die("Delete Save Routine");
//$j = count($del_uid);
//for($i=0; $i < $j; $i++) {
//    $db->sql_query("DELETE FROM `".$prefix."_nsngr_users` WHERE `uid`='$del_uid[$i]' AND `gid`='$gid'");
//    $db->sql_query("OPTIMIZE TABLE `".$prefix."_nsngr_users`");
//}
//Header("Location: ".$admin_file.".php?op=NSNGroupsUsersView&gid=$gid");

?>