<?php

define('_BUGREPORTTITLE','<h2>Platinum Bug Reporting</h2>');
define('_BUGREPORTNOTE','This is a new feature in Platinum Pro to allow admins and beta testers to submit there bug reports in a quick efficient and specialized manner.');
define('_MODULE','Module');
define('_MODULEDESC','<i>Select the module where you noticed the bug!</i>');
define('_AUTOPOP','(Auto Populated)');
define('_MYSQLVERSION','MySQL Version');
define('_PHPVERSION','PHP Version');
define('_SEND','Send');
define('_YOURNAME','Your Name');
define('_MESSAGE','Problem Description');
define('_YOUREMAIL','Your Email');
define('_FEEDBACK','Feedback');
define('_FBENTERNAME','ERROR: Please enter your name!');
define('_FBENTEREMAIL','ERROR: Please enter your e-mail address!');
define('_FBENTERMESSAGE','ERROR: Please enter a description of the problem!');
define('_SENDEREMAIL','Sender\'s Email');
define('_SENDERNAME','Sender\'s Name');
define('_FBMAILSENT','Mail has been sent!');
define('_FBMAILNOTSENT','Mail has not been sent!  Had error with mailer.');
define('_FBTHANKSFORCONTACT','Thank you for contacting us');
define('_SUBJECT','Subject');
define('_FBINVALIDNAME','ERROR: Name contains invalid text!');
define('_FBENTERSUBJECT','ERROR: Please enter a subject!');
if (!defined('_SECCODEINCOR')) define('_SECCODEINCOR','Security Code is incorrect, Please go back and type it exactly as given ...');
define('_FBINVALIDSUBJECT','ERROR: Subject contains invalid text!');
define('_FBRENTEREMAIL','ERROR: Please enter a valid Email!');
define('_ALLFIELDSREQUIRED','All Fields Required');
?>
