<?php



	global $admin_file;



    adminmenu($admin_file.".php?op=Snavi", "Snavi Menu", "snavi.png");



?>