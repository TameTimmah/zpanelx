<?php
/************************************************************************************************/
/**  Platinum Nuke Pro Theme																	*/
/**  ===============================															*/
/**  Theme Impressed_II 																		*/
/**  Designed By   : D. Miller AkA. DocHaVoC - http://www.havocst.net 							*/
/**  Theme Version : v1.0 (100% Width)															*/
/** Copyright     : A public theme for use with Platinum Nuke Pro http://www.platinumnuke.com	*/
/**																								*/
/**	  Copyright (c) 2011 D. Miller AkA. DocHaVoC | All Rights Reserved							*/
/************************************************************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "footer.php")) {
    die ("Access Denied");
}
echo "<table width=\"100%\" height=\"250\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" id=\"Table_01\">\n";
echo "<tr>\n";
echo "		<td rowspan=\"7\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_01.gif\" width=\"15\" height=\"250\" alt=\"\"></td>\n";
echo "		<td rowspan=\"7\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_02.gif\" width=\"99\" height=\"250\" alt=\"\"></td>\n";
echo "		<td rowspan=\"2\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_03.gif\" width=\"140\" height=\"82\" alt=\"\"></td>\n";
echo "		<td rowspan=\"7\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_03-05.gif\" width=\"80\" height=\"250\" alt=\"\"></td>\n";
echo "		<td  width=\"100%\" height=\"55\" background=\"themes/Impressed_II/images/Impressed_II_footer_05.gif\" alt=\"\"></td>\n";
echo "<td rowspan=\"7\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_05-07.gif\" width=\"85\" height=\"250\" alt=\"\"></td>\n";
echo "		<td rowspan=\"2\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_07.gif\" width=\"140\" height=\"82\" alt=\"\"></td>\n";
echo "		<td rowspan=\"7\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_08.gif\" width=\"100\" height=\"250\" alt=\"\"></td>\n";
echo "		<td rowspan=\"7\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_03-10.gif\" width=\"15\" height=\"250\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"55\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td rowspan=\"3\" width=\"100%\" height=\"152\"  background=\"themes/Impressed_II/images/Impressed_II_footer_10.gif\" alt=\"\"><div align=\"center\">$footer_message</div></td>\n";
echo "  <td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"27\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td width=\"140\" height=\"115\" background=\"themes/Impressed_II/images/Impressed_II_footer_11.gif\" alt=\"\"><div align=\"center\">$showlinks</div></td>\n";
echo "		<td width=\"140\" height=\"115\" background=\"themes/Impressed_II/images/Impressed_II_footer_12.gif\" alt=\"\"><div align=\"center\">$showdl</div></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"115\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td rowspan=\"2\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_13.gif\" width=\"140\" height=\"18\" alt=\"\"></td>\n";
echo "		<td rowspan=\"2\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_14.gif\" width=\"140\" height=\"18\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"10\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td width=\"100%\" height=\"43\" rowspan=\"3\" background=\"themes/Impressed_II/images/Impressed_II_footer_15.gif\" alt=\"\"></td>\n";
echo "  <td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"8\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td background=\"themes/Impressed_II/images/Impressed_II_footer_18.gif\" width=\"140\" height=\"16\" border=\"0\" alt=\"HaVoCst.net\"></td>\n";
echo "		<td background=\"themes/Impressed_II/images/Impressed_II_footer_19.gif\" width=\"140\" height=\"16\" border=\"0\" alt=\"Platinum Nuke\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"16\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_18-19.gif\" width=\"140\" height=\"19\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_footer_19-20.gif\" width=\"140\" height=\"19\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"19\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "</table>\n";
echo "	<div align=\"center\">Page Generation:&nbsp;$total_time</div>\n";
?>