<?php
/*
 * Theme Impressed_II 
 * http://www.havocst.net
 * @author D. Miller
 * @copyright 2011
 */
 
if (stristr($_SERVER['SCRIPT_NAME'], "header.php")) {
    die ("Access Denied");
}
echo "<table width=\"100%\" height=\"261\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" id=\"Table_01\">\n";
echo "<tr>\n";
echo "		<td rowspan=\"6\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_01.gif\" width=\"15\" height=\"260\" alt=\"\"></td>\n";
echo "		<td rowspan=\"6\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_02.gif\" width=\"87\" height=\"260\" alt=\"\"></td>\n";
echo "		<td rowspan=\"4\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_03.gif\" width=\"26\" height=\"221\" alt=\"\"></td>\n";
echo "		<td colspan=\"4\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_04.gif\" width=\"373\" height=\"41\" alt=\"\"></td>\n";
echo "		<td rowspan=\"4\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_05.gif\" width=\"5\" height=\"221\" alt=\"\"></td>\n";
echo "		<td rowspan=\"6\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_06.gif\" width=\"52\" height=\"260\" alt=\"\"></td>\n";
echo "		<td rowspan=\"3\" background=\"themes/Impressed_II/images/Impressed_II_header_07.gif\" width=\"100%\" height=\"213\" alt=\"\"></td>\n";
echo "		<td rowspan=\"3\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_08.gif\" width=\"147\" height=\"213\" alt=\"\"></td>\n";
echo "		<td rowspan=\"6\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_05-10.gif\" width=\"15\" height=\"260\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"41\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td colspan=\"4\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_10.gif\" width=\"373\" height=\"139\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"139\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td colspan=\"4\" rowspan=\"2\" background=\"themes/Impressed_II/images/Impressed_II_header_11.gif\" width=\"373\" height=\"41\" alt=\"\"><div align=\"center\">$slogan</div></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"33\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td rowspan=\"3\" align=\"right\" background=\"themes/Impressed_II/images/Impressed_II_header_12.gif\" width=\"100%\" height=\"47\">\n";
	include_once('themes/Impressed_II/tcmarquee_info.php');
echo "  </td>\n";
echo "		<td rowspan=\"3\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_13.gif\" width=\"147\" height=\"47\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"8\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td align=\"center\" colspan=\"2\" background=\"themes/Impressed_II/images/Impressed_II_header_14.gif\" width=\"102\" height=\"25\" alt=\"\"><strong><a href=\"" .   $themeconsole['link1'] . "\" class=menutitle>" . $themeconsole['link1text'] .
    "</a></strong></td>\n"; 
echo "		<td align=\"center\" background=\"themes/Impressed_II/images/Impressed_II_header_15.gif\" width=\"101\" height=\"25\" alt=\"\"><strong><a href=\"" .
    $themeconsole['link2'] . "\" class=menutitle>" . $themeconsole['link2text'] .
    "</a></strong></td>\n"; 
echo "		<td align=\"center\" background=\"themes/Impressed_II/images/Impressed_II_header_16.gif\" width=\"101\" height=\"25\" alt=\"\"><strong><a href=\"" .
    $themeconsole['link3'] . "\" class=menutitle>" . $themeconsole['link3text'] .
    "</a></strong></td>\n"; 
echo "		<td align=\"center\" background=\"themes/Impressed_II/images/Impressed_II_header_17.gif\" width=\"100\" height=\"25\" alt=\"\"><strong><a href=\"" .
    $themeconsole['link4'] . "\" class=menutitle>" . $themeconsole['link4text'] .
    "</a></strong></td>\n"; 
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"25\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td colspan=\"6\">\n";
echo "			<img src=\"themes/Impressed_II/images/Impressed_II_header_18.gif\" width=\"404\" height=\"14\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"1\" height=\"14\" alt=\"\"></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"15\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"87\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"26\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"76\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"101\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"101\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"95\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"5\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"52\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"232\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"147\" height=\"1\" alt=\"\"></td>\n";
echo "		<td>\n";
echo "			<img src=\"themes/Impressed_II/images/spacer.gif\" width=\"15\" height=\"1\" alt=\"\"></td>\n";
echo "		<td></td>\n";
echo "	</tr>\n";
echo "</table>\n";
?>