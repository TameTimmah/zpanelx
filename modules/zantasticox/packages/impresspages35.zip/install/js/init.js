if (document.images)
{
    preload_image = new Image();
    preload_image.src="design/cms_button_hover.gif";
}
