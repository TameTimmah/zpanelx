<?php
/**
 * @package ImpressPages

 *
 */
namespace Modules\administrator\system;


class UpdateException extends \Exception
{

}