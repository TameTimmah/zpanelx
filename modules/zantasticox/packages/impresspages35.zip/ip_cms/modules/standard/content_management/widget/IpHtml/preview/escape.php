<?php echo isset($html) ? htmlspecialchars($html) : ''; ?>
