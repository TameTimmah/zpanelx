<pre><?php echo isset($html) ? $html : ''; ?></pre>
