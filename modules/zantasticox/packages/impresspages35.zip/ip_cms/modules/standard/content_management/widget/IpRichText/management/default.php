<textarea name="text">
<?php echo isset($text) ? htmlentities($text, (ENT_COMPAT), 'UTF-8') : '' ?>
</textarea>
