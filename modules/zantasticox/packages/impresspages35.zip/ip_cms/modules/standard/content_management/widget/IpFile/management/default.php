<div class="ipWidget_ipFile_container">
</div>
<div class="ipgHide">
    <div class="ipaFileTemplate">
        <a href="#" class="ipaButton ipaFileMove"><?php echo $this->escPar('standard/content_management/widget_file/move') ?></a>
        <input type="text" class="ipAdminInput ipaFileTitle" name="title" value="" />
        <a href="#" class="ipaButton ipaFileLink" target="_blank"><?php echo $this->escPar('standard/content_management/widget_file/preview') ?></a>
        <a href="#" class="ipaButton ipaFileRemove"><?php echo $this->escPar('standard/content_management/widget_file/remove') ?></a>
    </div>
</div>
<a href="#" class="ipAdminButton ipmBrowseButton"><?php echo $this->escPar('standard/configuration/admin_translations/add_new'); ?></a>
