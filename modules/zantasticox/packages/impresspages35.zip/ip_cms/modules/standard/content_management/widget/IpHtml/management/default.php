<textarea name="text" class="ipAdminTextarea"><?php echo isset($html) ? htmlentities($html, (ENT_COMPAT), 'UTF-8') : ''; ?></textarea>
