<div class="ipaImage"></div>
<div class="ipaOptions">
    <label class="ipAdminLabel"><?php echo $this->escPar('standard/content_management/widget_image/title') ?></label>
    <input type="text" class="ipAdminInput ipaImageTitle" name="title" value="<?php echo htmlspecialchars(isset($title) ? $title : ''); ?>" />
</div>