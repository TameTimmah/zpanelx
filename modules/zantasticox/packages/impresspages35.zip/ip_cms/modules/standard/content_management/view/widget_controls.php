<div class="ipAdminWidgetControls">
    <a href="#" class="ipaButton ipActionWidgetManage"><span><?php echo $this->escPar('standard/content_management/admin_translations/man_paragraph_edit') ?></span></a>
    <a href="#" class="ipaButton ipActionWidgetMove"><span>Move</span></a>
    <a href="#" class="ipaButton ipActionWidgetDelete"><span><?php echo $this->escPar('standard/content_management/admin_translations/man_paragraph_delete') ?></span></a>
</div>
<div class="ipAdminWidgetMoveIcon"></div>