<dl class="ipwContainer ipwCollapsed">
    <dt class="ipwQuestion"><?php echo isset($question) ? htmlspecialchars($question) : ''; ?></dt>
    <dd class="ipwAnswer">
<?php echo isset($answer) ? $answer : ''; ?>
    </dd>
</dl>
