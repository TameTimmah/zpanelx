<div style="display: none;" id="ipSaveProgress">
    <div class="ipMainProgressbar"></div>
    <span class="ipSeleniumProgress">Progress</span>
</div>
