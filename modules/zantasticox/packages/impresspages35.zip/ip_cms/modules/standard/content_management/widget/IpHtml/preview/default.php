<?php echo isset($html) ? $html : ''; ?>
