<textarea class="ipaFieldOptionsRichText"></textarea>
