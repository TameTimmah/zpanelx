<!-- Included all widget data to pass to javascript. -->
<input type="hidden"
       class="ipAdminWidgetData"
       name="widgetInstance"
       value="<?php echo htmlspecialchars(json_encode($widgetInstance)); ?>" />
