<div class="ipaFieldOptionsContainer"></div>
<div class="ipgHide">
    <div class="ipaFieldOptionsTemplate">
        <a href="#" class="ipaButton ipaOptionMove"><?php echo $this->escPar('standard/content_management/widget_contact_form/move') ?></a>
        <input type="text" class="ipAdminInput ipaOptionLabel" name="option" value="" />
        <a href="#" class="ipaButton ipaOptionRemove"><?php echo $this->escPar('standard/content_management/widget_contact_form/remove') ?></a>
    </div>
</div>
<a href="#" class="ipAdminButton ipaFieldOptionsAdd">Add new</a>
