<?php echo $this->renderWidget('IpTitle', array('title' => $this->par('community/user/translations/title_registration'))); ?>
<?php echo $this->renderWidget('IpText', array('text' => $this->par('community/user/translations/text_registration_verified'))); ?>
<?php echo $this->renderWidget('IpUserLogin') ?>