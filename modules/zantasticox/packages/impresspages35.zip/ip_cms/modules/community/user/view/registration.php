<?php echo $this->renderWidget('IpTitle', array('title' => $this->par('community/user/translations/title_registration'))); ?>
<?php echo $this->renderWidget('IpUserRegistration'); ?>
