var ipModInlineManagementControls = '\
<div class="ipModuleInlineManagementControls">\
    <div class="ipAdminWidgetControls">\
        <a class="ipaButton ipActionWidgetManage" href="#"><span><?php echo $this->escPar('standard/configuration/admin_translations/edit'); ?></span></a>\
    </div>\
</div>\
';
