<div class="ipUploadWindow ui-widget-content">
    <div class="ipUploadButtons">
        <div class="ipUploadBrowseContainer">
            <a href="#" class="ipUploadImageButton ipUploadBrowseButton">Upload new</a> <?php // TODO: translate ?>
        </div>
        <a href="#" class="ipUploadImageButton ipUploadLargerButton">Larger</a> <?php // TODO: translate ?>
        <a href="#" class="ipUploadImageButton ipUploadSmallerButton">Smaller</a> <?php // TODO: translate ?>
    </div>
    <div class="ipUploadDragContainer">
        <img class="ipUploadImage" src="<?php echo BASE_URL.MODULE_DIR ?>developer/upload/img/empty.gif" alt="image" /> <?php // TODO: translate ?>
    </div>
</div>
