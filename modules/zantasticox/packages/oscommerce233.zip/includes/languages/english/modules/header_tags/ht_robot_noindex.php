<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_ROBOT_NOINDEX_TITLE', 'Robot NoIndex');
  define('MODULE_HEADER_TAGS_ROBOT_NOINDEX_DESCRIPTION', 'Add robot noindex tags to specified pages');
?>
