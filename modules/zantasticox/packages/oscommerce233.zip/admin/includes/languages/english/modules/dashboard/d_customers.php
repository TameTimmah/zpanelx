<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_CUSTOMERS_TITLE', 'Customers');
define('MODULE_ADMIN_DASHBOARD_CUSTOMERS_DESCRIPTION', 'Show the newest customers');
define('MODULE_ADMIN_DASHBOARD_CUSTOMERS_DATE', 'Date');
?>
