<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_SESSION_AUTO_START', 'session.auto_start is enabled - please disable this php feature in php.ini and restart the web server.');
?>
