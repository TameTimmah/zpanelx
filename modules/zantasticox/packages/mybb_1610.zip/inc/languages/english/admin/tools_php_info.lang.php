<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: tools_php_info.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

$l['php_info'] = "PHP Info";
$l['browser_no_iframe_support'] = "Your browser does not support iFrames.";

?>