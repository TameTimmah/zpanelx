<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: customhelpsections.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

/*
 * Custom Help Section Translation Format
 *
 * // Help Section {sid}
 * $l['s{sid}_name'] = "Section name";
 * $l['s{sid}_desc'] = "Section description";
 */
?>