<?php

header('Location: install/index.php');

?>